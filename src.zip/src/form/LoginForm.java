package form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import org.apache.struts.action.ActionMessage;

import dao.EmployeeDao;
import exception.DataAccessException;

@SuppressWarnings("serial")
public class LoginForm extends ActionForm {

	private String userid;
	private String password;

	EmployeeDao employeeDao = new EmployeeDao();

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@SuppressWarnings("finally")
	@Override
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		try {

			if (userid == null || userid.length() == 0)
				errors.add("userid", new ActionMessage("error.userid.required"));
			else if (password == null || password.length() == 0)
				errors.add("password", new ActionMessage(
						"error.password.required"));
			else if (!employeeDao.validUserId(userid))
				errors.add("invalidUserid", new ActionMessage(
						"error.invalid.userid"));
			else if (!employeeDao.checkPassword(userid, password))
				errors.add("invalidPassword", new ActionMessage(
						"error.invalid.password"));

		} catch (DataAccessException dae) {
			System.err
					.println("Problem in accessing data from database while loging ");
		} finally {
			return errors;
		}
	}
}
