package form;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import dao.EmployeeDao;
import exception.DataAccessException;

@SuppressWarnings("serial")
public class LeaveForm extends ActionForm {

	private int empno;
	private String lvType;
	private String lvStrtDt;
	private String lvStrtMon;
	private String lvStrtYear;
	private String lvEndDt;
	private String lvEndMon;
	private String lvEndYear;

	
	public int getEmpno() {
		return empno;
	}
	
	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getLvType() {
		return lvType;
	}

	public void setLvType(String lvType) {
		this.lvType = lvType;
	}

	public String getLvStrtDt() {
		return lvStrtDt;
	}

	public void setLvStrtDt(String lvStrtDt) {
		this.lvStrtDt = lvStrtDt;
	}

	public String getLvStrtMon() {
		return lvStrtMon;
	}

	public void setLvStrtMon(String lvStrtMon) {
		this.lvStrtMon = lvStrtMon;
	}

	public String getLvStrtYear() {
		return lvStrtYear;
	}

	public void setLvStrtYear(String lvStrtYear) {
		this.lvStrtYear = lvStrtYear;
	}

	public String getLvEndDt() {
		return lvEndDt;
	}

	public void setLvEndDt(String lvEndDt) {
		this.lvEndDt = lvEndDt;
	}

	public String getLvEndMon() {
		return lvEndMon;
	}

	public void setLvEndMon(String lvEndMon) {
		this.lvEndMon = lvEndMon;
	}

	public String getLvEndYear() {
		return lvEndYear;
	}

	public void setLvEndYear(String lvEndYear) {
		this.lvEndYear = lvEndYear;
	}

	@SuppressWarnings({ "deprecation", "finally" })
	@Override
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {
		
		ActionErrors errors = new ActionErrors();
		HttpSession session = request.getSession();
		
		String empStatus = (String) session.getAttribute("empStatus");
		EmployeeDao employeeDao = new EmployeeDao();
		Date currentDate = new Date();
		String months[] = {"0","jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		String lvStrtDate = lvStrtDt+"-"+months[Integer.parseInt(lvStrtMon)]+"-"+lvStrtYear;
		String lvEndDate = lvEndDt+"-"+months[Integer.parseInt(lvEndMon)]+"-"+lvEndYear;
		empno = (Integer) session.getAttribute("empno");
		session.setAttribute("lvStrtDate", lvStrtDate);
		session.setAttribute("lvEndDate", lvEndDate);
		//new Date(s)

		/***********************************Leave Type *************************************/
		try {
			
		if(!empStatus.equals("Confirmed"))
			errors.add("invalidConfirmStatus", new ActionMessage("error.invalidConfirmStatus"));
			
		if (lvType.equals("0"))
			errors.add("lvType", new ActionMessage("error.invalidLvType.required"));
		
		/***********************************Leave Start Date********************************/
		if (lvStrtDt.equals("0") || lvStrtMon.equals("0") || lvStrtYear.equals("0"))
			errors.add("leaveStartDt", new ActionMessage("error.leaveStartDt.required"));
		else if(
					(
						lvStrtMon.equals("2") && (lvStrtDt.equals("29") && Integer.parseInt(lvStrtYear)%4 != 0)
					)
					||
					(
						lvStrtMon.equals("2") && (lvStrtDt.equals("30") || lvStrtDt.equals("31"))
					)
				)	
			errors.add("invalidLeaveStartDt", new ActionMessage("error.invalidLeaveStartDt"));
		
		else if((lvStrtMon.equals("4") || lvStrtMon.equals("6") || 
					lvStrtMon.equals("9") || lvStrtMon.equals("11")) && lvStrtDt.equals("31"))
			errors.add("invalidLeaveStartDt", new ActionMessage("error.invalidLeaveStartDt"));
		
		else if( Integer.parseInt(lvStrtYear) < (currentDate.getYear()+1900))
			errors.add("maxLeaveStartDt", new ActionMessage("error.maxLeaveStartDt"));
		else if(Integer.parseInt(lvStrtYear) == (currentDate.getYear()+1900) && Integer.parseInt(lvStrtMon) < (currentDate.getMonth()+1))
			errors.add("maxLeaveStartDt", new ActionMessage("error.maxLeaveStartDt"));
		else if(Integer.parseInt(lvStrtYear) == (currentDate.getYear()+1900) && Integer.parseInt(lvStrtMon) == (currentDate.getMonth()+1) && Integer.parseInt(lvStrtDt) <= currentDate.getDate())
			errors.add("maxLeaveStartDt", new ActionMessage("error.maxLeaveStartDt"));
		
		else if(employeeDao.validEmpLeaveDetails(empno, lvStrtDate))
			errors.add("empLvFound", new ActionMessage("error.empLvFound"));
		
		
			
		
		/***********************************Leave End Date********************************/
		
		if (lvEndDt.equals("0") || lvEndMon.equals("0") || lvEndYear.equals("0"))
			errors.add("leaveEndDt", new ActionMessage("error.leaveEndDt.required"));
		else if(
					(
						lvEndMon.equals("2") && (lvEndDt.equals("29") && Integer.parseInt(lvEndYear)%4 != 0)
					)
					||
					(
						lvEndMon.equals("2") && (lvEndDt.equals("30") || lvEndDt.equals("31"))
					)
				)	
			errors.add("invalidLeaveEndDt", new ActionMessage("error.invalidLeaveEndDt"));
		
		else if((lvEndMon.equals("4") || lvEndMon.equals("6") || 
					lvEndMon.equals("9") || lvEndMon.equals("11")) && lvEndDt.equals("31"))
			errors.add("invalidLeaveEndDt", new ActionMessage("error.invalidLeaveEndDt"));
		
		else if( Integer.parseInt(lvEndYear) < Integer.parseInt(lvStrtYear))
			errors.add("maxLeaveEndDt", new ActionMessage("error.maxLeaveEndDt"));
		else if(Integer.parseInt(lvEndYear) == Integer.parseInt(lvStrtYear) && Integer.parseInt(lvEndMon) < Integer.parseInt(lvStrtMon))
			errors.add("maxLeaveEndDt", new ActionMessage("error.maxLeaveEndDt"));
		else if(Integer.parseInt(lvEndYear) == Integer.parseInt(lvStrtYear) && Integer.parseInt(lvEndMon) == Integer.parseInt(lvStrtMon) && Integer.parseInt(lvEndDt) < Integer.parseInt(lvStrtDt))
			errors.add("maxLeaveEndDt", new ActionMessage("error.maxLeaveEndDt"));
		}catch(DataAccessException dae){
			System.out
			.println("Problem in accessing data from database while logging ");
		}
		finally {
		return errors;
		}
		
	}

}
