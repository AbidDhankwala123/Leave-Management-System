package exception;

public class ConnectionFailureException extends RuntimeException {

	public ConnectionFailureException() {
		super();
	}

	public ConnectionFailureException(String message, Throwable cause) {
		super(message, cause);
	}

	public ConnectionFailureException(String message) {
		super(message);
	}

	public ConnectionFailureException(Throwable cause) {
		super(cause);
	}

}

