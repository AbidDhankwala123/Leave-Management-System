package customtag;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

@SuppressWarnings("serial")
public class ErrorTag extends TagSupport {

	private Map<String, String> errors = new LinkedHashMap<String, String>();

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}

	@Override
	public int doStartTag() throws JspException {

		JspWriter out = pageContext.getOut();

		try {

			if (errors != null) {
				if (errors.containsKey("blank"))
					out.print("* " + errors.get("blank"));
				else if (errors.containsKey("userid"))
					out.print("* " + errors.get("userid"));
				else if(errors.containsKey("password"))
					out.print("* " + errors.get("password"));
			}

		} catch (IOException ioe) {
			throw new JspException(ioe);
		}
		return SKIP_BODY;
	}
}
