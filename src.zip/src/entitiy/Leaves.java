package entitiy;

public class Leaves {

	private int empno;
	private String lvType;
	private String lvStrtDt;
	private String lvStrtMon;
	private String lvStrtYear;
	private String lvEndDt;
	private String lvEndMon;
	private String lvEndYear;
	
	private String leaveStartDate;
	private String leaveStatus;
	
	
	public String getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(String leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	public String getLeaveStatus() {
		return leaveStatus;
	}

	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getLvType() {
		return lvType;
	}

	public void setLvType(String lvType) {
		this.lvType = lvType;
	}

	public String getLvStrtDt() {
		return lvStrtDt;
	}

	public void setLvStrtDt(String lvStrtDt) {
		this.lvStrtDt = lvStrtDt;
	}

	public String getLvStrtMon() {
		return lvStrtMon;
	}

	public void setLvStrtMon(String lvStrtMon) {
		this.lvStrtMon = lvStrtMon;
	}

	public String getLvStrtYear() {
		return lvStrtYear;
	}

	public void setLvStrtYear(String lvStrtYear) {
		this.lvStrtYear = lvStrtYear;
	}

	public String getLvEndDt() {
		return lvEndDt;
	}

	public void setLvEndDt(String lvEndDt) {
		this.lvEndDt = lvEndDt;
	}

	public String getLvEndMon() {
		return lvEndMon;
	}

	public void setLvEndMon(String lvEndMon) {
		this.lvEndMon = lvEndMon;
	}

	public String getLvEndYear() {
		return lvEndYear;
	}

	public void setLvEndYear(String lvEndYear) {
		this.lvEndYear = lvEndYear;
	}
}
