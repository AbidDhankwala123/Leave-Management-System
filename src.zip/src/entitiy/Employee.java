package entitiy;

public class Employee {

	private int empno;
	private String lastname;
	private String firstName;
	private String gender;
	private String empStatus;
	private boolean isManager;
	
	public Employee() {
		
	}
	public Employee(int empno, String lastname, String firstName,
			String gender, String empStatus, boolean isManager) {
		super();
		this.empno = empno;
		this.lastname = lastname;
		this.firstName = firstName;
		this.gender = gender;
		this.empStatus = empStatus;
		this.isManager = isManager;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmpStatus() {
		return empStatus;
	}
	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}
	
	public boolean isManager() {
		return isManager;
	}

	

	

}
