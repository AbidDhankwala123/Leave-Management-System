package entitiy;

public class EmployeeLeaveRecords {

	private String lvStrtDt;
	private String lvEndDt;
	private String lvRequestDt;
	private String lvType;
	private int lvNoOfDays;
	private String lvStatus;
	private String apprRejectDt;
	private int sickLv;
	private int csLv;
	private int earnLv;
	private int matLv;
	private int patLv;
	private String months;
	private int lwpDays;
	private int lwpCalc;
	private int empno;
	private String firstName;
	private String lastName;
	private int years;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public EmployeeLeaveRecords() {
	
	}
	
	public EmployeeLeaveRecords(int sickLv, int csLv, int earnLv, int matLv, int patLv) {
		this.sickLv = sickLv;
		this.csLv = csLv;
		this.earnLv = earnLv;
		this.matLv = matLv;
		this.patLv = patLv;
	}

	public EmployeeLeaveRecords(String lvStrtDt, String lvEndDt,
			String lvRequestDt, String lvType, int lvNoOfDays, String lvStatus,
			String apprRejectDt, int sickLv, int csLv, int earnLv, int matLv,
			int patLv, String months, int lwpDays, int lwpCalc) {
		this.lvStrtDt = lvStrtDt;
		this.lvEndDt = lvEndDt;
		this.lvRequestDt = lvRequestDt;
		this.lvType = lvType;
		this.lvNoOfDays = lvNoOfDays;
		this.lvStatus = lvStatus;
		this.apprRejectDt = apprRejectDt;
		this.sickLv = sickLv;
		this.csLv = csLv;
		this.earnLv = earnLv;
		this.matLv = matLv;
		this.patLv = patLv;
		this.months = months;
		this.lwpDays = lwpDays;
		this.lwpCalc = lwpCalc;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apprRejectDt == null) ? 0 : apprRejectDt.hashCode());
		result = prime * result + csLv;
		result = prime * result + earnLv;
		result = prime * result + empno;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((lvEndDt == null) ? 0 : lvEndDt.hashCode());
		result = prime * result + lvNoOfDays;
		result = prime * result + ((lvRequestDt == null) ? 0 : lvRequestDt.hashCode());
		result = prime * result + ((lvStatus == null) ? 0 : lvStatus.hashCode());
		result = prime * result + ((lvStrtDt == null) ? 0 : lvStrtDt.hashCode());
		result = prime * result + ((lvType == null) ? 0 : lvType.hashCode());
		result = prime * result + lwpCalc;
		result = prime * result + lwpDays;
		result = prime * result + matLv;
		result = prime * result + ((months == null) ? 0 : months.hashCode());
		result = prime * result + patLv;
		result = prime * result + sickLv;
		result = prime * result + years;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeLeaveRecords other = (EmployeeLeaveRecords) obj;
		if (apprRejectDt == null) {
			if (other.apprRejectDt != null)
				return false;
		} else if (!apprRejectDt.equals(other.apprRejectDt))
			return false;
		if (csLv != other.csLv)
			return false;
		if (earnLv != other.earnLv)
			return false;
		if (empno != other.empno)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (lvEndDt == null) {
			if (other.lvEndDt != null)
				return false;
		} else if (!lvEndDt.equals(other.lvEndDt))
			return false;
		if (lvNoOfDays != other.lvNoOfDays)
			return false;
		if (lvRequestDt == null) {
			if (other.lvRequestDt != null)
				return false;
		} else if (!lvRequestDt.equals(other.lvRequestDt))
			return false;
		if (lvStatus == null) {
			if (other.lvStatus != null)
				return false;
		} else if (!lvStatus.equals(other.lvStatus))
			return false;
		if (lvStrtDt == null) {
			if (other.lvStrtDt != null)
				return false;
		} else if (!lvStrtDt.equals(other.lvStrtDt))
			return false;
		if (lvType == null) {
			if (other.lvType != null)
				return false;
		} else if (!lvType.equals(other.lvType))
			return false;
		if (lwpCalc != other.lwpCalc)
			return false;
		if (lwpDays != other.lwpDays)
			return false;
		if (matLv != other.matLv)
			return false;
		if (months == null) {
			if (other.months != null)
				return false;
		} else if (!months.equals(other.months))
			return false;
		if (patLv != other.patLv)
			return false;
		if (sickLv != other.sickLv)
			return false;
		if (years != other.years)
			return false;
		return true;
	}

	public String getLvStrtDt() {
		return lvStrtDt;
	}

	public void setLvStrtDt(String lvStrtDt) {
		this.lvStrtDt = lvStrtDt;
	}

	public String getLvEndDt() {
		return lvEndDt;
	}

	public void setLvEndDt(String lvEndDt) {
		this.lvEndDt = lvEndDt;
	}

	public String getLvRequestDt() {
		return lvRequestDt;
	}

	public void setLvRequestDt(String lvRequestDt) {
		this.lvRequestDt = lvRequestDt;
	}

	public String getLvType() {
		return lvType;
	}

	public void setLvType(String lvType) {
		this.lvType = lvType;
	}

	public int getLvNoOfDays() {
		return lvNoOfDays;
	}

	public void setLvNoOfDays(int lvNoOfDays) {
		this.lvNoOfDays = lvNoOfDays;
	}

	public String getLvStatus() {
		return lvStatus;
	}

	public void setLvStatus(String lvStatus) {
		this.lvStatus = lvStatus;
	}

	public String getApprRejectDt() {
		return apprRejectDt;
	}

	public void setApprRejectDt(String apprRejectDt) {
		this.apprRejectDt = apprRejectDt;
	}

	public int getSickLv() {
		return sickLv;
	}

	public void setSickLv(int sickLv) {
		this.sickLv = sickLv;
	}

	public int getCsLv() {
		return csLv;
	}

	public void setCsLv(int csLv) {
		this.csLv = csLv;
	}

	public int getEarnLv() {
		return earnLv;
	}

	public void setEarnLv(int earnLv) {
		this.earnLv = earnLv;
	}

	public int getMatLv() {
		return matLv;
	}

	public void setMatLv(int matLv) {
		this.matLv = matLv;
	}

	public int getPatLv() {
		return patLv;
	}

	public void setPatLv(int patLv) {
		this.patLv = patLv;
	}

	public String getMonths() {
		return months;
	}

	public void setMonths(String months) {
		this.months = months;
	}

	public int getLwpDays() {
		return lwpDays;
	}

	public void setLwpDays(int lwpDays) {
		this.lwpDays = lwpDays;
	}

	public int getLwpCalc() {
		return lwpCalc;
	}

	public void setLwpCalc(int lwpCalc) {
		this.lwpCalc = lwpCalc;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}
}
