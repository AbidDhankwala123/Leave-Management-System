package dbutil;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import exception.ConnectionFailureException;

public class DBManager {

	public static Connection getConnection() throws ConnectionFailureException {
		try {
			// loading the properties file
			InputStream stream = DBManager.class.getClassLoader()
					.getResourceAsStream(
							"dbutil/db.properties"); // preferred
																		// code
																		// for
																		// loading
																		// the
																		// properties
																		// file

			Properties dbProps = new Properties();
			dbProps.load(stream);

			String driverClassName = dbProps.getProperty("driverClassName");
			Class.forName(driverClassName);

			String url = dbProps.getProperty("url");
			String user = dbProps.getProperty("user");
			String password = dbProps.getProperty("password");
			return DriverManager.getConnection(url, user, password);

		} catch (IOException ioe) {
			throw new ConnectionFailureException(
					"Unable to load db.properties file");
		} catch (ClassNotFoundException cnfe) {
			throw new ConnectionFailureException(
					"Unable to load the JDBC Driver. "
							+ "Please check if the driver jar has beed added to the classpath correctly"
							+ " or you might have done a spelling mistake");
		} catch (SQLException sqle) {
			throw new ConnectionFailureException(
					"Unable to connect to the database", sqle);
		}
	}
}
