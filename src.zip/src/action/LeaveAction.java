package action;


import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.MappingDispatchAction;

import dao.EmployeeDao;
import entitiy.Employee;
import entitiy.EmployeeLeaveRecords;
import entitiy.Leaves;


import form.LeaveForm;
import form.LoginForm;

public class LeaveAction extends MappingDispatchAction {

	public ActionForward login(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		LoginForm loginForm = (LoginForm) form;

		EmployeeDao employeeDao = new EmployeeDao();
		
		HttpSession session = request.getSession();
		
		Employee empDetails = employeeDao.getEmpDetails(loginForm.getUserid());
		
		String firstName = empDetails.getFirstName();
		String lastName = empDetails.getLastname();
		int empno = empDetails.getEmpno();
		String gender = empDetails.getGender();
		String empStatus = empDetails.getEmpStatus();
		
		session.setAttribute("name", firstName+" "+lastName);
		session.setAttribute("empno", empno);
		session.setAttribute("gender", gender);
		session.setAttribute("empStatus", empStatus);
		
		
		if (empDetails.isManager()) {
			return mapping.findForward("Msuccess");
		} else
			return mapping.findForward("success");

	}
	
	public ActionForward confirmApplyLeave(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		LeaveForm leaveForm = (LeaveForm) form;

		Leaves leaves = new Leaves();

		EmployeeDao employeeDao = new EmployeeDao();

		BeanUtils.copyProperties(leaves, leaveForm);

		employeeDao.applyLeave(leaves);

		return mapping.findForward("success");
	}

	public ActionForward empLeaveRecords(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		HttpSession session = request.getSession();
		EmployeeDao employeeDao = new EmployeeDao();
		
		int empno=(Integer)session.getAttribute("empno");
		
		List<EmployeeLeaveRecords> empList = employeeDao.viewEmployeeLeaveRecords(empno);
		LinkedHashSet<EmployeeLeaveRecords> set = new LinkedHashSet<EmployeeLeaveRecords>(empList);
		set.removeIf(e -> e.getLvStrtDt() == null);
		session.setAttribute("empList", set);
		
		empList = empList.stream().map(e -> new EmployeeLeaveRecords(e.getSickLv(), e.getCsLv(), e.getEarnLv(), e.getMatLv(), e.getPatLv()))
				.collect(Collectors.toList());
		
		LinkedHashSet<EmployeeLeaveRecords> empAvailableList = new LinkedHashSet<EmployeeLeaveRecords>(empList);
		session.setAttribute("empAvailableList", empAvailableList);
		
		List<EmployeeLeaveRecords> empLwpList = employeeDao.getEmpLwpDetails(empno);
		session.setAttribute("empLwpList", empLwpList);
		
		return mapping.findForward("success");
	}
	
	public ActionForward mgrViewEmpLvRecords(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		HttpSession session = request.getSession();
		EmployeeDao employeeDao = new EmployeeDao();
		
		int empno=(Integer)session.getAttribute("empno");
		
		List<EmployeeLeaveRecords> mgrList = employeeDao.mgrViewEmpLeaveRecords(empno);
		session.setAttribute("mgrList", mgrList);

		return mapping.findForward("success");
	}
	
	public ActionForward applyLeave(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		return mapping.findForward("success");
	}
	
	
	public ActionForward approveRejectLeaves(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		EmployeeDao employeeDao = new EmployeeDao();
		Leaves leave = new Leaves();
		leave.setEmpno(Integer.parseInt(request.getParameter("empNo")));
		leave.setLeaveStartDate(request.getParameter("lvStartDate"));
		leave.setLeaveStatus(request.getParameter("leaveStatus"));
		employeeDao.approveRejectEmpLeaves(leave);
		return mapping.findForward("success");
	}
	
	public ActionForward logout(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession();
		session.invalidate();
		return mapping.findForward("success");
	}
}
