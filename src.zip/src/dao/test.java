package dao;

public class test {

	public static void main(String[] args) throws Exception {

	
		System.out.println("Hello");
		
	}
}
