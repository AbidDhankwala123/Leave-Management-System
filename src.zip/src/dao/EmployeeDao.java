package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import dbutil.DBManager;
import entitiy.Employee;
import entitiy.EmployeeLeaveRecords;
import entitiy.Leaves;
import exception.DataAccessException;


public class EmployeeDao {

	public boolean validUserId(String userid) throws DataAccessException {

		Connection conn = null;

		PreparedStatement cstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnection();
			String SQL = "select 1 from employee_master where EMP_USER_ID=?";
			cstmt = conn.prepareStatement(SQL);
			cstmt.setString(1, userid);
			rs = cstmt.executeQuery();
			return rs.next();

		} catch (SQLException sqle) {
			throw new DataAccessException("Validating an UserId failed", sqle);
		} finally {
			try {
				rs.close();
				cstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
	
	public boolean checkPassword(String userid,String password) throws DataAccessException {

		Connection conn = null;

		PreparedStatement cstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnection();
			String SQL = "select 1 from employee_master where EMP_USER_ID=? and EMP_PASSWORD=?";
			cstmt = conn.prepareStatement(SQL);
			cstmt.setString(1, userid);
			cstmt.setString(2, password);
			
			rs = cstmt.executeQuery();
			return rs.next();

		} catch (SQLException sqle) {
			throw new DataAccessException("Validating Password failed", sqle);
		} finally {
			try {
				rs.close();
				cstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}

	public Employee getEmpDetails(String userid) throws DataAccessException {

		Connection conn = null;

		PreparedStatement cstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnection();
			String SQL = "select * from employee_master where EMP_USER_ID=?";
			cstmt = conn.prepareStatement(SQL);
			cstmt.setString(1, userid);
			rs = cstmt.executeQuery();
			rs.next();
			int empno=rs.getInt("EMP_NO");
			String lastName= rs.getString("EMP_LNAME");
			String firstName= rs.getString("EMP_FNAME");
			String gender= rs.getString("EMP_GENDER");
			String empStatus = rs.getString("EMP_STATUS");
			int managerId = rs.getInt("EMP_REPORTS_TO");
			boolean isManager = empno == managerId;
			return (new Employee(empno, lastName, firstName, gender, empStatus, isManager));

		} catch (SQLException sqle) {
			throw new DataAccessException("Getting Employees details failed", sqle);
		} finally {
			try {
				rs.close();
				cstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
	
	public boolean validEmpLeaveDetails(int empno, String lvStrtDt) throws DataAccessException {

		Connection conn = null;

		PreparedStatement cstmt = null;
		ResultSet rs = null;

		try {
			SimpleDateFormat sf = new SimpleDateFormat("dd-MMM-yyyy");
			Date dt = sf.parse(lvStrtDt);
			conn = DBManager.getConnection();
			String SQL = "select 1 from Employee_Leave_Details where EMP_NO=? and LEAVE_START_DATE=?";
			cstmt = conn.prepareStatement(SQL);
			cstmt.setInt(1, empno);
			cstmt.setDate(2, new java.sql.Date(dt.getTime()));
			
			rs = cstmt.executeQuery();
			return rs.next();

		} catch (Exception sqle) {
			throw new DataAccessException("Getting Employees details failed", sqle);
		} finally {
			try {
				rs.close();
				cstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
	
	public void applyLeave(Leaves leave) throws DataAccessException {

		Connection conn = null;
		CallableStatement cstmt = null;
		String months[] = {"0","jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
		String lvStrtDate = leave.getLvStrtDt()+"-"+months[Integer.parseInt(leave.getLvStrtMon())]+"-"+leave.getLvStrtYear();
		String lvEndDate = leave.getLvEndDt()+"-"+months[Integer.parseInt(leave.getLvEndMon())]+"-"+leave.getLvEndYear();
		
		
		try {
			conn = DBManager.getConnection();
			String SQL = "{call new_emp_lv_details_pack.new_emp_lv_details_proc(?,?,?,?)}";
			cstmt = conn.prepareCall(SQL);
			cstmt.setInt(1, leave.getEmpno());		
			cstmt.setString(2, lvStrtDate);
			cstmt.setString(3, leave.getLvType());
			cstmt.setString(4, lvEndDate);
			
			cstmt.executeUpdate();

		} catch (SQLException sqle) {
			throw new DataAccessException("Application for Leave Failed", sqle);
		} finally {
			try {
				cstmt.close();
			} catch (Exception e) {
			}
		}
		try {
			conn.close();
		} catch (Exception e) {
		}

	}
	
	public List<EmployeeLeaveRecords> viewEmployeeLeaveRecords(int empno)
			throws DataAccessException { 
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; 
		try {
			conn = DBManager.getConnection();
			String sql = "SELECT * FROM LEAVE_MASTER lv_mstr join LWP_DETAILS lwp on lv_mstr.emp_no=lwp.emp_no " + 
					"        left join EMPLOYEE_LEAVE_DETAILS eld on lwp.emp_no=eld.emp_no " + 
					"WHERE lwp.emp_no=? ORDER BY leave_request_date desc";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, empno);
			rs = pstmt.executeQuery();

			List<EmployeeLeaveRecords> list = new ArrayList<EmployeeLeaveRecords>(100); 

			while (rs.next()) {
				
				SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				String LvStrtDt = rs.getDate("LEAVE_START_DATE") != null ? dateFormatter.format(rs.getDate("LEAVE_START_DATE")) : null;
				String LvEndDate=rs.getDate("LEAVE_END_DATE") != null ? dateFormatter.format(rs.getDate("LEAVE_END_DATE")) : null;
				String LvReqDate=rs.getDate("LEAVE_REQUEST_DATE") != null ?dateFormatter.format(rs.getDate("LEAVE_REQUEST_DATE")) : null;
				String ApprRejectDate;
				if(rs.getDate("MANAGER_APPROVAL_REJECTED_DATE") != null)
					ApprRejectDate=dateFormatter.format(rs.getDate("MANAGER_APPROVAL_REJECTED_DATE"));
				else
					ApprRejectDate = " ";
				
				
				EmployeeLeaveRecords emp = new EmployeeLeaveRecords();				
				emp.setLvStrtDt(LvStrtDt);
				emp.setLvEndDt(LvEndDate);
				emp.setLvRequestDt(LvReqDate);
				emp.setLvType(rs.getString("LEAVE_TYPE"));
				emp.setLvNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				emp.setLvStatus(rs.getString("LEAVE_STATUS"));
				emp.setApprRejectDt(ApprRejectDate);
				emp.setSickLv(rs.getInt("SICK_LEAVE"));
				emp.setCsLv(rs.getInt("CASUAL_LEAVE"));
				emp.setEarnLv(rs.getInt("EARNED_LEAVE"));
				emp.setMatLv(rs.getInt("M_LEAVE"));
				emp.setPatLv(rs.getInt("P_LEAVE"));
				list.add(emp);
			}
			return list;

		} catch (SQLException sqle) {
			throw new DataAccessException("Getting an Employee Records Details failed", sqle);
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				pstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
	
	public List<EmployeeLeaveRecords> getEmpLwpDetails(int empno)
			throws DataAccessException { 
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; 
		try {
			conn = DBManager.getConnection();
			String sql = "SELECT * FROM lwp_details WHERE emp_no=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, empno);
			rs = pstmt.executeQuery();

			List<EmployeeLeaveRecords> list = new ArrayList<EmployeeLeaveRecords>(100); 

			while (rs.next()) {
				
				
				EmployeeLeaveRecords emp = new EmployeeLeaveRecords();				
				emp.setMonths(rs.getString("MONTHS"));
				emp.setYears(rs.getInt("YEARS"));
				emp.setLwpDays(rs.getInt("LWP_DAYS"));
				emp.setLwpCalc(rs.getInt("LWP_CALC"));
				list.add(emp);
			}
			return list;

		} catch (SQLException sqle) {
			throw new DataAccessException("Getting an Employee LWP Records Details failed", sqle);
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				pstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
  

	public List<EmployeeLeaveRecords> mgrViewEmpLeaveRecords(int mgrId)
			throws DataAccessException { 
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; // for select statements
		try {
			conn = DBManager.getConnection();
			String sql = "select * from Employee_Master em join Employee_Leave_Details eld on em.emp_no = eld.emp_no " + 
					"where emp_reports_to=? ORDER BY leave_request_date desc";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,  mgrId);
			rs = pstmt.executeQuery();

			List<EmployeeLeaveRecords> list = new ArrayList<EmployeeLeaveRecords>(); 

			while (rs.next()) {
				
				SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
				String LvStrtDt = dateFormatter.format(rs.getDate("LEAVE_START_DATE"));
				String LvEndDate=dateFormatter.format(rs.getDate("LEAVE_END_DATE"));
				String LvReqDate=dateFormatter.format(rs.getDate("LEAVE_REQUEST_DATE"));
				
				EmployeeLeaveRecords emp = new EmployeeLeaveRecords();	
				emp.setEmpno(rs.getInt("EMP_NO"));
				emp.setFirstName(rs.getString("EMP_FNAME"));
				emp.setLastName(rs.getString("EMP_LNAME"));
				emp.setLvRequestDt(LvReqDate);
				emp.setLvType(rs.getString("LEAVE_TYPE"));
				emp.setLvStrtDt(LvStrtDt);
				emp.setLvEndDt(LvEndDate);
				emp.setLvNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				emp.setLvStatus(rs.getString("LEAVE_STATUS"));
				list.add(emp);
			}
			return list;

		} catch (SQLException sqle) {
			throw new DataAccessException("Getting an Employee Records Details failed", sqle);
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				pstmt.close();
			} catch (Exception e) {
			}

			try {
				conn.close();
			} catch (Exception e) {
			}

		}
	}
	
	public void approveRejectEmpLeaves(Leaves leave) throws DataAccessException {

		Connection conn = null;
		CallableStatement cstmt = null;
		
		
		try {
			conn = DBManager.getConnection();
			String SQL = "{call updt_manager_status_pack.updt_manager_status_proc(?,?,?)}";
			cstmt = conn.prepareCall(SQL);
			cstmt.setInt(1, leave.getEmpno());		
			cstmt.setString(2, leave.getLeaveStartDate());
			cstmt.setString(3, leave.getLeaveStatus());
			
			cstmt.executeUpdate();

		} catch (SQLException sqle) {
			throw new DataAccessException("Updating Employee Leaves Failed", sqle);
		} finally {
			try {
				cstmt.close();
			} catch (Exception e) {
			}
		}
		try {
			conn.close();
		} catch (Exception e) {
		}
	}
	
}
